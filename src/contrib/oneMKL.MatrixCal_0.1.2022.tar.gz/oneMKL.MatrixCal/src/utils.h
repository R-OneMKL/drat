#include <Rcpp.h>

SEXP cast_numeric(SEXP input);
